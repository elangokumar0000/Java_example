/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// public class Main
// {
// 	public static void main(String[] args) {
// 	int n=5;
// 	int mid=(n+1)/2;
// 	for(int i=1;i<=n;i++)
// 	{
// 	    for(int j=1;j<=n;j++){
// 	        if(j==1||i==1||i==mid||j==n&&i<=mid||i==j&&i>=mid)
// 	        {
// 	            System.out.print("*");
// 	        }
// 	        else{
// 	            System.out.print(" ");
// 	        }
	        
// 	    }
// 	    System.out.println();
// 	}
	
// 	}
	
// }
// import java.util.Scanner;
// public class Main
// {
//     public static void main(String[]args){
//         Scanner sc=new Scanner(System.in);
//         int n=sc.nextInt();
//         int sum=n%10;
//         while(n>9){
//             n=n/10;
//         }
//         sum=sum+n;
//         System.out.println(sum);
        
//     }
// }
import java.util.*;
public class Main{
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        int n =sc.nextInt();
        int rev=0,temp=n;
        while(n!=0){
            int la=n%10;
            rev=rev*10+la;
            n/=10;
        }
        System.out.println((rev==temp)?"yes":"no");
    }
}