import java.util.*;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello");
		Doubly obj=new Doubly();
		obj.addLast(12);
		obj.addLast(14);
		obj.addLast(15);
	}
}
class node{
    
node prev,next;
int data;
node(int data){
    this.data=data;
    prev=next=null;
}
}
class Doubly{
    node head,tail;
    Doubly(){
        head=tail=null;}
    void addLast(int value){
        node latest=new node(value);
        if(head==null){
            head=tail=latest;
        }
        else{
            tail.next=latest;
            latest.prev=tail;
            tail=latest;
        }
    }
    void delLast(){
        try{
            if(head==null)throw new Exception("no data to delete");
        }catch(Exception o){
            System.out.println(o);
        }
        if(head==tail)
        head=tail=null;
        else{
            tail=tail.prev;
            tail.next=null;
        }
    }
}

