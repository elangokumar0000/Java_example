//function
#include <stdio.h>

// void oddoreven(int value){ //formal parameter
//     if(value%2==0){
//         printf("even\n");
//     }
//     else{
//         printf("odd\n");
//     }
// }
// int main(){
//     oddoreven(13); //function call
//     oddoreven(16); //actual parameter //argument
//     oddoreven(18);
// }
int prime(int n){  
    int count=0;
    for(int i=1;i<=n;i++){  //12 //2
        if(n%i==0){       //12%2==0
            count++;  //1
        }
    }
    if(count==2){
        return 1;
    }
    else{
        return 0;
    }
}
int main(){
    int n=15,m=16;
    int res=prime(n);
    printf("%d\n",res);
    printf("%d",0);
}