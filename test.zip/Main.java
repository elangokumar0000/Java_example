// import java.util.*;
// public class Main
// {
// 	public static void main(String[] args) {
// 	Scanner sc=new Scanner(System.in);
// 	String a=sc.nextLine();
// 	String b[]=a.split(",");
// 	LinkedHashSet<String> res=new LinkedHashSet<>();
// 	for(String k:b){
// 	    res.add(k);
// 	}
// 	res.forEach(k->System.out.println(k+" "));
// 	}
//      Scanner sc=new Scanner(System.in);
//      int a=sc.nextInt();
//      for(int i=1;i<a;i++){
//         if(i%3==0){
//             System.out.println("Fizz");
//         }
//         else if(i%5==0){
//             System.out.println("Buzz");
//         }

//         else
//         System.out.println(i);
//     }
    
// }
// }
// import java.util.*;
// class solVe{
//     public static void main(String []VK){
//         Scanner sc= new Scanner(System.in);
//         long a= sc.nextLong();
//         int evenCount=0,oddCount=0;
//         while(a!=0){
//             int last = (int)(a%10); 
//             if(last % 2  ==0  ){
//                 evenCount++;
//             }
//             else oddCount++;
//             a/=10;
//         }
//       System.out.println(oddCount==evenCount);
//     }
// }
// import java.util.*;
// public class Main{
//     public static void main(String[]args){
//         Scanner sc=new Scanner(System.in);
//         int a=sc.nextInt();
//         int c=sc.nextInt();
//         int d=sc.nextInt();
//         //System.out.println(Math.max(a,Math.max(c,d)));
//         System.out.println(a>c&&a>d ?a:c>d ?c:d);
        
//     }
// }
// import java.util.*;
// public class Main{
//     public static void main(String[]args){
//     Scanner sc=new Scanner(System.in);
//     int a=sc.nextInt();
//     for(int i=1;i<a;i++){
//         if(a%i==0){
//             if(i%2==1){
//                 System.out.println(i);
//             }
//         }
//     }
//     }
// }
// import java.util.*;
// import java.math.BigInteger;
// public class Main
// {
// 	public static void main(String[] args) {
//     int a =1234;
//     System.out.printf("%12d\n", a);
//     float b= 12.3446f;
//     System.out.printf("%12.3f", b);
// 	}
// }

// // --1234
import java.util.*;
public class Main{
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        if(a%2==0&&(a>=5&&a<=50)){
            System.out.println("fizz");
        }
        else if(a%2==1){
            System.out.println("buzz");
        }
        else {
            System.out.println("buzz");
        }
    }
}