 import java.util.*;
// public class Main{
//     public static void main(String[]args){
//         Scanner sc=new Scanner(System.in);
//         int a=sc.nextInt(),c=0;
//       while(a>0){
//           int b=a%10;
//           c=c+b;
//           a=a/10;
//       }
//       System.out.println(c);
//     }
// }
// public class Main{
//     public static void main(String[]args){
//         Scanner sc=new Scanner(System.in);
//         int a=sc.nextInt();
//         char b[]=String.valueOf(a).toCharArray();
//         for(int i=0;i<b.length;i=i+2){
//             if(i+1<b.length){
//             char temp=b[i];
//             b[i]=b[i+1];
//             b[i+1]=temp;
//             }
//         }
//         a = Integer.parseInt(String.valueOf(b));
//         System.out.println(a);
// }
//     }

    