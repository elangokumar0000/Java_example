import java.util.*;
class Father{
    int house;
    Father(){
        System.out.print("Father Constructor");
        house=3;}
    void Swim(){
        System.out.println("i can swim");
    }
}
class son extends Father{
    String car;
    son(){
        System.out.println("son constro");
        car="suprra";}
    void Sleep(){
        System.out.println("dead sleep");
    }
} 
    public class Main{
        public static void main(String[]args){
            son s= new son();
            System.out.print(s.car);
            s.Swim();
        
    }
}
