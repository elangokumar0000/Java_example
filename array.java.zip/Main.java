// import java.util.*;
// class Main{
// public static void main(String []args){
// Scanner sc= new Scanner (System.in);
// int n=sc.nextInt();
// int a[]=new int[n];
// for(int i=0;i<n;a[i++]=sc.nextInt());
// int max=a[0],min=a[0];
// for(int i=1;i<n;i++){
// if(a[i]>max) 
// max=a[i];
// if(a[i]<min)
// min=a[i];
// }
// System.out.print(max+" "+min);

// }
// }
// import java.util.*;

// public class Main {
//     public static void main(String[] args) {
//         Scanner sc=new Scanner(System.in);
//       int a=sc.nextInt(),c;
//       int b[]=new int[a];
//       for(int i=0;i<a;i++)
//       {
//          b[i]=sc.nextInt();
//       }
//       int sum=0;
//       for(int i=0;i<a;i++)
//       {
//          sum=sum+b[i];
//       }
//       System.out.println(sum);
//   }
// }
// import java.util.*;

// public class Main {
//     public static void main(String[] args) {
//          Scanner sc=new Scanner(System.in);
//       int a=sc.nextInt(),c;
//       int b[]=new int[a];
//       for(int i=0;i<a;i++)
//       {
//          b[i]=sc.nextInt();
//       }
//       Arrays.sort(b);
//       System.out.println(b[a-1]+" "+b[0]);
//   }
// }
// import java.util.*;

// public class Main {
//     public static void main(String[] args) {
//       Scanner sc=new Scanner(System.in);
//       int a=sc.nextInt();
//       int b[]=new int[a];
//       for(int i=0;i<a;i++)
//       {
//          b[i]=sc.nextInt();
//       }
//       int pos=0,neg=0;
//       for(int i=0;i<a;i++)
//       {
//          if(b[i]>0)
//          {
//           pos++;
//          }
//          else{
//           neg++;
//          }
//       }
//       System.out.print("pos : "+ pos+" neg : "+neg);
//   }
// }
// import java.util.*;

// public class Main {
//     public static void main(String[] args) {
//       Scanner sc=new Scanner(System.in);
//       int a=sc.nextInt();
//       int b[]=new int[a];
//       for(int i=0;i<a;i++)
//       {
//          b[i]=sc.nextInt();
//       }
//       int temp=b[a-1];
//       b[a-1]=b[0];
//       b[0]=temp;
//       for(int i=0;i<a;i++)
//       {
//          System.out.print(b[i]+" ");
//       }
//     }
// }
// import java.util.*;

// public class Main {
//     public static void main(String[] args) {
//       Scanner sc=new Scanner(System.in);
//       int a=sc.nextInt(),i,j;
//       int b=sc.nextInt();
//       for(i=a;i<=b;i++)
//       {
//          for(j=2;j<i;j++)
//          {
//           if(i%j==0)
//           {
//              break;
//           }
//          }
       
//       if(i==j)
//       System.out.print(i+" ");
//       }
//   }
// }
// import java.util.*;

// public class Main {
//     public static void main(String[] args) {
//          Scanner sc=new Scanner(System.in);
//       int a=sc.nextInt(),c;
//       int b[]=new int[a];
//       for(int i=0;i<a;i++)
//       {
//          b[i]=sc.nextInt();
//       }
//       int sum=0,sum2=0;
//       for(int i=0;i<a;i++)
//       {
//         if(i%2==0&&b[i]%2!=0)
//         {
//           sum=sum+b[i];
//         }
//         else if(i%2!=0&&b[i]%2==0)
//         {
//           sum2=sum2+b[i];
//         }
//       }
//       System.out.println(sum2+" "+sum);
//   }
// }
// import java.util.*;
// public class Main
// {
//     public static void main(String[]args){
//         Scanner sc=new Scanner(System.in);
//         int n=sc.nextInt(),m=sc.nextInt();
//         int a[]= new int[n],b[]= new int[m];
//         for(int i=0;i<n;a[i++]=sc.nextInt());
//          for(int i=0;i<m;a[i++]=sc.nextInt());
//          int c[]=new int[a.length+b.length];
//          for(int i=0;i<a.length;i++)
//          {
//              c[i]=a[i];
//          }
//          for(int i=0;i<b.length;i++)
//          {
//              c[a.length+i]=b[i];
//          }
//          System.out.println(Arrays.toString(c));
//     }
//}
// import java.util.*;
// public class Main{
//   public static void main(String[]args){
//     Scanner sc = new Scanner(System.in);
//     int r=sc.nextInt(),c=sc.nextInt();
//     int a[][]=new int[r][c];
//     for(int i=0;i<r;i++){
//       for(int j=0;j<c;j++){
//         a[i][j]=sc.nextInt();
//       }
//     }
//     for(int i=0;i<a.length;i++){
//       if(i%2==0){
//         for(int j=0;j<a[i].length;j++){
//           System.out.print(a[i][j]+" ");
//         }
//       }
//       else{
//         for(int j=a[i].length-1;j>=0;j--){
//           System.out.print(a[i][j]+" ");
//         }
//       }
//       System.out.println();
//     }
//   }
// }
// import java.util.*;
// public class Main{

//   public static void main(String[]args){
//   Scanner sc = new Scanner(System.in);
//   //for 2d array value is must
//   int r =sc.nextInt();
//   int a[][]=new int[r][];
//   //JaggedArray creation
//       for(int i=0;i<r;i++)
//       a[i] = new int[sc.nextInt()];
//       //input
//       for(int i=0;i<r;i++){
//          for(int j=0;j<a[i].length;j++){
//           a[i][j]=sc.nextInt();
//          }
//       }
//       //outpur
//       for (int row[]:a){
//          for(int k:row){
//           System.out.print(k+" ");
//          }
//          System.out.println();
//       }
//   }
//   }
// import java.util.*;
// public class Main{

//   public static void main(String[]args){
//   Scanner sc = new Scanner(System.in);
//   //for 2d array value is must
//   int r =sc.nextInt(),c=sc.nextInt();
//   int a[][]=new int[r][c];
//       for(int i=0;i<r;i++){
//          for(int j=0;j<a[i].length;j++){
//           a[i][j]=sc.nextInt();
//          }
//       }
//       int sum=0;
//       for (int i=0;i<r;i++){
//          for(int j=0;j<c;j++){
//              sum=sum+a[i][j];
//          }
//          System.out.println(sum);
//          sum=0;
//       }
//   }
//   }
// import java.util.*;
// public class Main{

//   public static void main(String[]args){
//   Scanner sc = new Scanner(System.in);
//   //for 2d array value is must
//   int r =sc.nextInt(),c=sc.nextInt();
//   int a[][]=new int[r][c];
//       for(int i=0;i<r;i++){
//          for(int j=0;j<a[i].length;j++){
//           a[i][j]=sc.nextInt();
//          }
//       }
//       int sum=0,sum2=0;
//       for (int i=0;i<r;i++){
//          for(int j=0;j<c;j++){
//              if(i==j)
//              sum=sum+a[i][j];
//              if(i+j==r-1)
//              sum2=sum2+a[i][j];
//          }
         
//       }
       
//   }
//   }
