import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner obj=new Scanner(System.in);
	    int bank[]={3420,3245,2231,3421,3245};
	    int pin[]={1111,2222,3333,4444,5555};
	    int ph[]={3457,5454,2343,2123,2345};
	    System.out.println("------WELCOME TO OUR BANK------");
	    System.out.println("press\n1.Deposite\n2.withdraw\n3.balance\n4.pin change\n5.exit");
	    int n=obj.nextInt();
	    int userb,userp,damount;
	    switch(n){
	        case 1:{
	            System.out.print("Enter your Account Number :");
	            userb=obj.nextInt();
	            System.out.print("Enter your Account Phone No :");
	            userp=obj.nextInt();
	            for(int i=0;i<bank.length;i++)
	              if(bank[i]==userb&&ph[i]==userp)
	              {
	                  System.out.print("Enter Deposite amount :");
	                  damount=obj.nextInt();
	                  break;
	              }
	              else if(bank[i]==userb&&ph[i]!=userp)
	                System.out.println("------Invalied detile-------");
	                else if(bank[i]!=userb&&ph[i]==userp)
	                System.out.println("------Invalied detile-------");
	                
	                
	           }
	      }
	}
}
