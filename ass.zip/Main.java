import java.util.*;
class Main{
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt(),sum=0;
        int b[]=new int[a];
        for(int i=0;i<a;i++){
            b[i]=sc.nextInt();
        }
        for(int i=1;i<a;i++){
            int c=b[i-1]-b[i];
            int d=Math.abs(c);
            sum+=d;
            System.out.print(d+" ");
        }
        System.out.println();
        System.out.println(sum);
    }
}