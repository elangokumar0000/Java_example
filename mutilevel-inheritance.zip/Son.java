class Son extends Father{
    String car;
    Son(){
        System.out.println("Son Constructor");
        car ="Mustang";
    }
    void kabaddi(){
        System.out.println("I am a Kabaddi player");
    }
}