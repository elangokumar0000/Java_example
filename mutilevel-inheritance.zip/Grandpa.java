class Grandpa{
    int land ;
    Grandpa(){
        System.out.println("Grandpa Constructor");
        land = 500;
    }
    void FarmHouse(){
        System.out.println("I have 100sq feet FarmHouse");
    }
}