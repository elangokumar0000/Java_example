public class Main
{
	public static void main(String[] args) {
	Grandpa g = new Grandpa();
    Father f = new Father();
    Son s = new Son();
	}
}
