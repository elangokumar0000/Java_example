class Father extends Grandpa{
    int house;
    Father(){
        System.out.println("Father Constructor");
        house = 3;
    }
    void business(){
      System.out.println("I have Minning business");  
    }
}