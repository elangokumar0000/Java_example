class Father{
    int bankBalance ;
    Father(){
        System.out.println("Father constructor");
        bankBalance= 100000;
    }
}