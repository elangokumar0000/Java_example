class Daughter extends Father{
    int balance ;
    String car;
     Daughter(){
         System.out.println("Daughter Constructor");
         balance= 50000;
         car ="Tesla";
     }
}