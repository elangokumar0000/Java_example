class Son extends Father{
    int balance ;
    String car;
    Son(){
        System.out.println("son constructor");
        balance= 50000;
        car ="Mustang";
    }
}