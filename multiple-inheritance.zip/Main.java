
class Main{
    public static void main (String[] args) {
        Son s= new Son();
        Daughter d = new Daughter();
        System.out.println(s.bankBalance);
        System.out.println(d.bankBalance);
    }
}