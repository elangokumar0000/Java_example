import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int a=sc.nextInt();
	    double b=sc.nextDouble();
	    sc.nextLine();
	    String c=sc.nextLine();
		System.out.println(c);
		String d=String.format("%.2f",b);
		System.out.println(d);
		System.out.println(a);
	}
}
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    String a1[]=sc.nextLine();
	    int vol=0,con=0;
	    
	    for(int i=0;i<a1.length();i++)
    {
	    if(a[i]=="a"||a[i]=="e"||a[i]=="i"||a[i]=="o"||a[i]=="u")
	    vol++;
	    else
	    con++;
    }
		System.out.println("vol : "+vol);
		System.out.println("con : "+con);
	}
}

