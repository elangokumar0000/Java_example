//import java.util.*;
// public class Main
// {
// 	public static void main(String[] args) {
// 		Scanner sc=new Scanner(System.in);
// 		int n=sc.nextInt();
// 		int a[]=new int[n];
// 		for(int i=0;i<n;i++)
// 		{
// 		    a[i]=sc.nextInt();
// 		}
// 		for(int i=0;i<n;i++)
// 		{
// 		   System.out.print(a[i]+" ");
// 		}
		
// 	}
// }
//enhanced for loop
// public class Main
// {
//     public static void main(String[]args){
//         Scanner sc=new Scanner(System.in);
//         int n =sc.nextInt();
//         int a[]=new int[n];
//         for(int i=0;i<n;i++)
//         {
//             a[i]=sc.nextInt();
//         }
//         int sum=0;
//         for(int k:a)
//         {
//             System.out.print(k+" ");
//             sum+=k;
//         }
//     }
// }
// public class Main
// {
//     public static void main(String[]args)
//     {
//         Scanner sc=new Scanner(System.in);
//         int n=sc.nextInt();
//         int a[]=new int[n];
//         for(int i=0;i<n;a[i++]=sc.nextInt());
//         System.out.print("[");
//         for(int i=0;i<n;i++)
//         {   if(i!=n-1)
//             System.out.print(a[i]+",");
//             else
//             System.out.print(a[i]);
//         }
//         System.out.print("]");
//     }
// }
// package Arrays;
// import java.util.*;
// public class Main
// {
//     public static void main(String[]args)
//     {
//         Scanner sc=new Scanner(System.in);
//         int n=sc.nextInt();
//         int a[]=new int[n];
//         for(int i=0;i<n;a[i++]=sc.nextInt());
//         System.out.println(Arrays.toString(a));
//         Arrays.sort(a);
//         System.out.println(Arrays.toString(a));
//     }
// }    
package Array;
import java.util.*;
public class Main {
	public static void main(String []args){
	     Scanner sc = new Scanner(System.in);
	     int n= sc.nextInt();
	     int a[]=new int[n];
	     for(int i=0;i<n;i++)
	     a[i]=sc.nextInt();
	    System.out.println(Arrays.toString(a));
	     Arrays.sort(a);
	    System.out.println(Arrays.toString(a));
	    
//binarySearch(int[] a, int key)
	     System.out.println(Arrays.binarySearch(a,6));
	 //binarySearch(int[] a, int fromIndex, int toIndex, int key)
	     System.out.println(Arrays.binarySearch(a,1,4,6));
	     //	copyOf(int[] original, int newLength)
	     int b[]=Arrays.copyOf(a,10);
	    System.out.println(Arrays.toString(b));
	    //	copyOfRange(int[] original, int from, int to)
	    int c[]= Arrays.copyOfRange(a,3,6);
	    System.out.println(Arrays.toString(c));
	   //	fill(int[] a, int val)
	    int d[]=new int[n];
	    Arrays.fill(d,6);
	    System.out.println(Arrays.toString(d));
	   //	parallelSort(int[] a, int fromIndex, int toIndex)
	    Arrays.parallelSort(a,0,6); 
	    System.out.println(Arrays.toString(a));
	 	    }
}