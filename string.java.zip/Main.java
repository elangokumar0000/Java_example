// import java.util.*;
// public class Main
// {
// 	public static void main(String[] args) {
// 	    String a="User";
//  	    String b="User";
// // 	    String c="user";
// // 	    String d=a;
	    
// // 		System.out.println(a==b);
// // 		d="UserOne";
// // 		System.out.println(a==d);
// // 		System.out.println(a==c);
//         String c=new String("User");
//         String d=new String(a);
//         //System.out.println(a.hashcode()+" "+c.hashcode());
//         System.out.println(a==c);
//          System.out.println(a==d);
//           System.out.println(c==d);
//           System.out.println(a==b);
//           b=d;
//             System.out.println(a==b);
// 	}
// }
// import java.util.*;
// public class Main
// {
// 	public static void main(String[] args) {
// 	    Scanner sc =new Scanner(System.in);
// 	    String n=sc.next();
// 	    System.out.println(n);
// 	    sc.nextLine();
// 	    String a=sc.nextLine();
// 	    System.out.println(a);
// 	}
// }
// import java.util.*;
// public class Main{
//     public static void main(String[]args){
//         Scanner sc =new Scanner(System.in);
//         String a=sc.next(),b=sc.next();
//         System.out.println(a.charAt(2));
//         System.out.println(a.codePointBefore(1));
//         System.out.println(a.codePointAt(0));
//         System.out.println(a.codePointCount(0,2));
//         System.out.println(a.compareTo(b)); 
//         System.out.println(a.compareToIgnoreCase(b));
//         String c="hello";
//         String d= new String("hello");
//         String e="hello";
//         System.out.println(c.equals(d));
//         System.out.println(c.equalsIgnoreCase(d));
//         System.out.println(c==d);
//         System.out.println(c==e);
//     }
// }
// import java.util.*;
// public class Main{
//     public static void main(String[]args){
//         Scanner sc =new Scanner(System.in);
//         String a=sc.next(),b=sc.next();
//         System.out.println(a.indexOf('R'));
//         System.out.println(a.indexOf('R',3));
//         System.out.println(a.indexOf("ING"));
//         System.out.println(a.indexOf("IG",2));
//     }
// }
// import java.util.*;
// public class Main{
//     public static void main(String[]args){
//         Scanner sc =new Scanner(System.in);
//         String a=sc.next();
//         String b=new  String (sc.next());
//         System.out.println(a==b);
//         b=b.intern();
//         System.out.println(a==b);
//     }
// }
import java.util.*;
public class Main{
     public static void main(String[]args){
         int a=1239,b=1234;
         a=a+b;
         //int cd[]=newInt[]{1,2,3,4}
         String c= String.valueOf(a);
        System.out.println(a);
     }
}