
#include <stdio.h>

// int main()
// {
//     int a[3][3];
//     for(int i=0;i<3;i++)
//     {
//         for(int j=0;j<3;j++)
//         scanf("%d",&a[i][j]);
//     }

//     for(int i=0;i<3;i++)
//     {
//         for(int j=0;j<3;j++)
//     {
//     printf("%d ",a[i][j]);
//     }
//     printf("\n");
//     }
// }   
// }
// int main()
// {
//      int r,c;
//      scanf("%d %d",&r,&c);
//     int a[r][c];
//     for(int i =0 ;i< r; i++){
//       for(int j =0 ;j< c ;j++){
//       scanf("%d",&a[i][j]); 
//       }
//     }
//     for(int i =0 ;i< r; i++){
//       for(int j =0 ;j< c ;j++){
//         printf("%d ",a[i][j]); 
//       }
//       printf("\n");
//     }
// }

//pointer
// int main()
// {
//     int size;
//     int *sizepionter=&size;
//     scanf("%d",sizepionter);
//     int a[*sizepionter];
//     int *arr=a;
//     for (int i=0;i<*sizepionter;i++)
//     {
//         scanf("%d",arr+i);
//     }
//     for (int i=0;i<*sizepionter;i++)
//     {
//         printf("%d ",*(arr+i));
//     }
// }
// int main()
// {
//     int a=12;
//     int*p=&a;
//     int **ptr=&p;
//          *p=123;
//          **ptr=56;
//          printf("%d",a);
// }

